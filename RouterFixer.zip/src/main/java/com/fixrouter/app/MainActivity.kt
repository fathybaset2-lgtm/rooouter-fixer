package com.fixrouter.app

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Bundle
import android.text.InputType
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean

private val C_PRIMARY = Color.parseColor("#1565C0")
private val C_PRIMARY_DARK = Color.parseColor("#0D47A1")
private val C_BG = Color.parseColor("#F2F4F7")
private val C_FIELD = Color.parseColor("#F7F8FA")
private val C_STROKE = Color.parseColor("#D8DCE3")
private val C_MUTED = Color.parseColor("#6B7280")
private val C_LOG = Color.parseColor("#12161C")

private val MODE_LABELS = arrayOf("802.11b", "802.11g", "802.11n", "802.11b/g", "802.11b/g/n")
private val MODE_VALUES = arrayOf("b", "g", "n", "b/g", "b/g/n")
private val DSL_NAMES = arrayOf(
    "G.dmt", "T1.413", "G.lite", "ADSL2", "ADSL2+", "ALL(AnnexA/L)", "ADSL2/ADSL2+(AnnexM)"
)
private val DSL_VALS = arrayOf("G.dmt", "T1.413", "G.lite", "ADSL2", "ADSL2+", "ALL", "AnnexM")

class MainActivity : Activity() {
    private lateinit var scroll: ScrollView
    private lateinit var logView: TextView
    private lateinit var fixBtn: Button
    private lateinit var readBtn: Button
    private lateinit var devicesBtn: Button
    private lateinit var cbDslOn: CheckBox
    private val cbDsl = ArrayList<CheckBox>()
    private lateinit var cbBitswap: CheckBox
    private lateinit var cbSra: CheckBox
    private lateinit var etRouterUser: EditText
    private lateinit var etRouterPass: EditText
    private lateinit var etPppUser: EditText
    private lateinit var etPppPass: EditText
    private lateinit var etSsid: EditText
    private lateinit var etWifiPass: EditText
    private lateinit var etMax: EditText
    private lateinit var spMode: Spinner
    private lateinit var cbHide: CheckBox

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun gap(topDp: Int, bottomDp: Int): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, dp(topDp), 0, dp(bottomDp))
        return lp
    }

    private fun prefs() = getSharedPreferences("cfg", Context.MODE_PRIVATE)

    private fun field(
        hint: String,
        key: String,
        def: String,
        secret: Boolean = false,
        numeric: Boolean = false
    ): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(prefs().getString(key, def))
        e.inputType = if (numeric) {
            InputType.TYPE_CLASS_NUMBER
        } else if (secret) {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        } else {
            InputType.TYPE_CLASS_TEXT
        }
        e.background = bg(C_FIELD, 10, C_STROKE, 1)
        e.setPadding(dp(12), dp(10), dp(12), dp(10))
        e.textSize = 15f
        return e
    }

    private fun bg(fill: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(fill)
        d.cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor)
        return d
    }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = bg(Color.WHITE, 14, C_STROKE, 1)
        c.setPadding(dp(16), dp(14), dp(16), dp(16))
        val t = TextView(this)
        t.text = title
        t.textSize = 15f
        t.setTypeface(null, Typeface.BOLD)
        t.setTextColor(C_PRIMARY)
        c.addView(t)
        parent.addView(c, gap(12, 0))
        return c
    }

    private fun label(parent: LinearLayout, text: String) {
        val t = TextView(this)
        t.text = text
        t.textSize = 13f
        t.setTextColor(C_MUTED)
        parent.addView(t, gap(12, 4))
    }

    private fun addTo(parent: LinearLayout, v: View) {
        parent.addView(v, gap(10, 0))
    }

    private fun spinnerBox(parent: LinearLayout, sp: Spinner) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = bg(C_FIELD, 10, C_STROKE, 1)
        box.setPadding(dp(4), dp(2), dp(4), dp(2))
        box.addView(sp, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        parent.addView(box, gap(0, 0))
    }

    private fun styleBtn(b: Button, fill: Int, textColor: Int, stroke: Int, textSp: Float, heightDp: Int) {
        b.background = bg(fill, 12, stroke, if (stroke != 0) 1 else 0)
        b.setTextColor(textColor)
        b.isAllCaps = false
        b.textSize = textSp
        b.stateListAnimator = null
        b.minHeight = dp(heightDp)
        b.minimumHeight = dp(heightDp)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = C_PRIMARY_DARK

        val outer = LinearLayout(this)
        outer.orientation = LinearLayout.VERTICAL
        outer.layoutDirection = View.LAYOUT_DIRECTION_LTR
        outer.setBackgroundColor(C_BG)

        // ---------- header ----------
        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        header.setBackgroundColor(C_PRIMARY)
        header.setPadding(dp(20), dp(18), dp(20), dp(18))
        val title = TextView(this)
        title.text = "Router Fixer"
        title.textSize = 22f
        title.setTypeface(null, Typeface.BOLD)
        title.setTextColor(Color.WHITE)
        header.addView(title)
        val note = TextView(this)
        note.text = "HG531 • Connect to the router's Wi-Fi (even with no internet), then tap the button. The app talks to the router only."
        note.textSize = 13f
        note.setTextColor(Color.parseColor("#D6E4FF"))
        header.addView(note, gap(4, 0))
        outer.addView(header)

        // ---------- fields ----------
        etRouterUser = field("Router username", "ru", "admin")
        etRouterPass = field("Router password", "rp", "admin", secret = true)
        etPppUser = field("ADSL line username (digits only)", "pu", "", numeric = true)
        etPppPass = field("ADSL line password", "pp", "", secret = true)
        etSsid = field("Wi-Fi name (SSID)", "ss", "")
        etWifiPass = field("Wi-Fi password (min 8 characters)", "wp", "", secret = true)
        etMax = field("Max connected devices", "mx", "5", numeric = true)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(4), dp(16), dp(28))

        // ---------- router login ----------
        val cRouter = card(root, "Router login")
        addTo(cRouter, etRouterUser)
        addTo(cRouter, etRouterPass)
        val cbShow = CheckBox(this)
        cbShow.text = "Show passwords"
        cbShow.setOnCheckedChangeListener { _, on ->
            val variation = if (on) {
                InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            } else {
                InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            for (e in listOf(etRouterPass, etPppPass, etWifiPass)) {
                e.inputType = InputType.TYPE_CLASS_TEXT or variation
                e.setSelection(e.text.length)
            }
        }
        cRouter.addView(cbShow, gap(6, 0))

        // ---------- ADSL ----------
        val cPpp = card(root, "Internet line (ADSL)")
        addTo(cPpp, etPppUser)
        addTo(cPpp, etPppPass)

        // ---------- wifi ----------
        val cWifi = card(root, "Wi-Fi")
        addTo(cWifi, etSsid)
        addTo(cWifi, etWifiPass)
        addTo(cWifi, etMax)
        label(cWifi, "Network mode")
        spMode = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, MODE_LABELS)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spMode.adapter = adapter
        spMode.setSelection(prefs().getInt("mode", 4))
        spinnerBox(cWifi, spMode)
        cbHide = CheckBox(this)
        cbHide.text = "Hide network name"
        cbHide.isChecked = prefs().getBoolean("hide", true)
        cWifi.addView(cbHide, gap(8, 0))

        // ---------- DSL ----------
        val cDsl = card(root, "DSL settings")
        cbDslOn = CheckBox(this)
        cbDslOn.text = "Change DSL settings"
        cbDslOn.setTypeface(null, Typeface.BOLD)
        cbDslOn.isChecked = prefs().getBoolean("dslOn", false)
        cDsl.addView(cbDslOn, gap(6, 0))

        label(cDsl, "Modulation type")
        val savedModes = prefs().getString("dm", "ADSL2+")!!.split(",")
        for (i in DSL_NAMES.indices) {
            val cb = CheckBox(this)
            cb.text = DSL_NAMES[i]
            cb.isChecked = savedModes.contains(DSL_VALS[i])
            cbDsl.add(cb)
            cDsl.addView(cb, gap(2, 0))
        }
        for (i in cbDsl.indices) {
            cbDsl[i].setOnCheckedChangeListener { _, on ->
                if (on) {
                    if (i >= 5) {
                        for (j in cbDsl.indices) {
                            if (j != i && cbDsl[j].isChecked) cbDsl[j].isChecked = false
                        }
                    } else {
                        cbDsl[5].isChecked = false
                        cbDsl[6].isChecked = false
                    }
                }
            }
        }

        label(cDsl, "DSL capability")
        cbBitswap = CheckBox(this)
        cbBitswap.text = "Bitswap Enable"
        cbBitswap.isChecked = prefs().getBoolean("bs", true)
        cDsl.addView(cbBitswap, gap(2, 0))
        cbSra = CheckBox(this)
        cbSra.text = "SRA Enable"
        cbSra.isChecked = prefs().getBoolean("sra", false)
        cDsl.addView(cbSra, gap(2, 0))

        val dslHint = TextView(this)
        dslHint.text = "If \"Change DSL settings\" is off, the router's DSL settings are left untouched. ALL and AnnexM clear the other choices (same as the router page)."
        dslHint.textSize = 12f
        dslHint.setTextColor(C_MUTED)
        cDsl.addView(dslHint, gap(8, 0))

        val applyDslState = {
            val on = cbDslOn.isChecked
            for (cb in cbDsl) cb.isEnabled = on
            cbBitswap.isEnabled = on
            cbSra.isEnabled = on
        }
        cbDslOn.setOnCheckedChangeListener { _, _ -> applyDslState() }
        applyDslState()

        // ---------- actions ----------
        fixBtn = Button(this)
        fixBtn.text = "Fix router now"
        styleBtn(fixBtn, C_PRIMARY, Color.WHITE, 0, 17f, 54)
        fixBtn.setOnClickListener { startJob(true) }
        root.addView(fixBtn, gap(20, 0))

        readBtn = Button(this)
        readBtn.text = "Read current settings"
        styleBtn(readBtn, Color.WHITE, C_PRIMARY, C_PRIMARY, 16f, 50)
        readBtn.setOnClickListener { startJob(false) }
        root.addView(readBtn, gap(10, 0))

        devicesBtn = Button(this)
        devicesBtn.text = "Show connected devices"
        styleBtn(devicesBtn, Color.WHITE, C_PRIMARY, C_PRIMARY, 16f, 50)
        devicesBtn.setOnClickListener { startJob(false, true) }
        root.addView(devicesBtn, gap(10, 0))

        // ---------- log ----------
        logView = TextView(this)
        logView.typeface = Typeface.MONOSPACE
        logView.textSize = 13f
        logView.setTextColor(Color.parseColor("#D6E2F0"))
        logView.background = bg(C_LOG, 12)
        logView.setPadding(dp(14), dp(12), dp(14), dp(12))
        logView.minHeight = dp(110)
        logView.setTextIsSelectable(true)
        logView.layoutDirection = View.LAYOUT_DIRECTION_LTR
        logView.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        logView.hint = "Log will appear here..."
        logView.setHintTextColor(Color.parseColor("#6B7280"))
        root.addView(logView, gap(18, 0))

        scroll = ScrollView(this)
        scroll.isFillViewport = false
        scroll.addView(root)
        outer.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(outer)
    }

    private fun log(s: String) {
        runOnUiThread {
            logView.append(s + "\n")
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun setBusy(busy: Boolean) {
        runOnUiThread {
            fixBtn.isEnabled = !busy
            readBtn.isEnabled = !busy
            devicesBtn.isEnabled = !busy
            val al = if (busy) 0.5f else 1f
            fixBtn.alpha = al
            readBtn.alpha = al
            devicesBtn.alpha = al
        }
    }

    private fun bad(msg: String): Config? {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        return null
    }

    private fun readConfig(): Config? {
        val ppp = etPppUser.text.toString().trim()
        if (ppp.isEmpty() || ppp.length > 15 || !ppp.all { it in '0'..'9' }) {
            return bad("Line username must be English digits only (up to 15)")
        }
        val pppPass = etPppPass.text.toString()
        if (pppPass.isEmpty()) return bad("Enter the ADSL line password")
        val ssid = etSsid.text.toString()
        if (ssid.isEmpty() || ssid.length > 32) return bad("Wi-Fi name must be 1 to 32 characters")
        val wifiPass = etWifiPass.text.toString()
        if (wifiPass.length < 8 || wifiPass.length > 63) return bad("Wi-Fi password must be 8 to 63 characters")
        val max = etMax.text.toString().trim().toIntOrNull()
        if (max == null || max < 1 || max > 32) return bad("Device count must be 1 to 32")
        var dslValue = "none"
        if (cbDslOn.isChecked) {
            val picked = cbDsl.indices.filter { cbDsl[it].isChecked }.map { DSL_VALS[it] }
            if (picked.isEmpty()) return bad("Pick at least one DSL modulation type")
            dslValue = picked.joinToString(",")
        }
        return Config(
            routerUser = etRouterUser.text.toString().trim(),
            routerPass = etRouterPass.text.toString(),
            pppDigits = ppp,
            pppSuffix = "@tedata.net.eg",
            pppPass = pppPass,
            wifiSsid = ssid,
            wifiPass = wifiPass,
            hide = cbHide.isChecked,
            maxDevices = max,
            mode = MODE_VALUES[spMode.selectedItemPosition.coerceIn(0, MODE_VALUES.size - 1)],
            dsl = dslValue,
            bitswap = cbBitswap.isChecked,
            sra = cbSra.isChecked
        )
    }

    private fun save() {
        prefs().edit()
            .putString("ru", etRouterUser.text.toString())
            .putString("rp", etRouterPass.text.toString())
            .putString("pu", etPppUser.text.toString())
            .putString("pp", etPppPass.text.toString())
            .putString("ss", etSsid.text.toString())
            .putString("wp", etWifiPass.text.toString())
            .putString("mx", etMax.text.toString())
            .putBoolean("hide", cbHide.isChecked)
            .putInt("mode", spMode.selectedItemPosition)
            .putBoolean("dslOn", cbDslOn.isChecked)
            .putString("dm", cbDsl.indices.filter { cbDsl[it].isChecked }.joinToString(",") { DSL_VALS[it] })
            .putBoolean("bs", cbBitswap.isChecked)
            .putBoolean("sra", cbSra.isChecked)
            .apply()
    }

    private fun startJob(apply: Boolean, devices: Boolean = false) {
        val cfg: Config? = if (devices) null else (readConfig() ?: return)
        val ru = etRouterUser.text.toString().trim()
        val rp = etRouterPass.text.toString()
        if (!devices) save()
        logView.text = ""
        log("Looking for the Wi-Fi network...")
        setBusy(true)

        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val req = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .build()
        val started = AtomicBoolean(false)
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                if (!started.compareAndSet(false, true)) return
                val self = this
                Thread {
                    work(network, cfg, apply, devices, ru, rp)
                    try {
                        cm.unregisterNetworkCallback(self)
                    } catch (e: Exception) {
                    }
                }.start()
            }

            override fun onUnavailable() {
                log("No Wi-Fi connected. Connect to the router's network first and try again.")
                setBusy(false)
            }
        }
        cm.requestNetwork(req, cb, 10000)
    }

    private fun work(network: Network, c: Config?, apply: Boolean, devices: Boolean, ru: String, rp: String) {
        var router: Router? = null
        try {
            val r = Router(network) { msg -> log(msg) }
            router = r
            log("Logging in to the router...")
            r.login(ru, rp)
            log("Logged in.")
            if (devices) {
                r.listDevices().forEach { line -> log(line) }
            } else if (apply && c != null) {
                r.setPpp(c)
                Thread.sleep(3000)
                if (c.dsl != "none") {
                    r.setDsl(c)
                    Thread.sleep(3000)
                }
                r.setWifi(c)
                log("")
                log("Done. Wait a minute for the router to apply the settings.")
                log("Your phone may disconnect briefly and reconnect to the new network.")
                try {
                    Thread.sleep(5000)
                    r.verify().forEach { line -> log(line) }
                } catch (e: Exception) {
                    log("Could not verify right now (normal if Wi-Fi dropped). Tap 'Read current settings' in a minute.")
                }
            } else {
                r.verify().forEach { line -> log(line) }
            }
        } catch (e: RouterException) {
            log("Error: " + e.message)
        } catch (e: Exception) {
            log("Connection error: " + (e.message ?: e.javaClass.simpleName))
        } finally {
            try {
                router?.logout()
            } catch (e: Exception) {
            }
            setBusy(false)
        }
    }
}

// ===================== Router client =====================

class RouterException(msg: String) : Exception(msg)

data class Config(
    val routerUser: String,
    val routerPass: String,
    val pppDigits: String,
    val pppSuffix: String,
    val pppPass: String,
    val wifiSsid: String,
    val wifiPass: String,
    val hide: Boolean,
    val maxDevices: Int,
    val mode: String,
    val dsl: String,
    val bitswap: Boolean,
    val sra: Boolean
)

class Router(
    private val network: Network,
    private val base: String = "http://192.168.1.1",
    private val log: (String) -> Unit
) {
    private val cookies = LinkedHashMap<String, String>()
    private val wan = "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.1"
    private val wlan = "InternetGatewayDevice.LANDevice.1.WLANConfiguration.1"
    private val pppPage = "/html/quickconfig/quicksetppp.asp"
    private val dslPage = "/html/ntwkall/dsl.asp"
    private val dslDomain = "InternetGatewayDevice.WANDevice.1.WANDSLInterfaceConfig"
    private val wlanPage = "/html/ntwkall/wlan.asp"
    private val quoted = Regex("\"((?:[^\"\\\\]|\\\\.)*)\"")

    private fun request(
        method: String,
        path: String,
        form: Map<String, String>? = null,
        referer: String? = null
    ): String {
        val conn = network.openConnection(URL(base + path)) as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 10000
            conn.readTimeout = 20000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            if (cookies.isNotEmpty()) {
                conn.setRequestProperty("Cookie", cookies.entries.joinToString("; ") { it.key + "=" + it.value })
            }
            if (referer != null) conn.setRequestProperty("Referer", referer)
            if (form != null) {
                val body = form.entries.joinToString("&") {
                    URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
                }.toByteArray(Charsets.UTF_8)
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                conn.setFixedLengthStreamingMode(body.size)
                conn.outputStream.use { it.write(body) }
            }
            val code = conn.responseCode
            for ((hk, hv) in conn.headerFields) {
                if (hk != null && hk.equals("Set-Cookie", ignoreCase = true)) {
                    for (c in hv) {
                        val kv = c.substringBefore(";")
                        val k = kv.substringBefore("=").trim()
                        val v = kv.substringAfter("=", "").trim()
                        if (k.isNotEmpty()) cookies[k] = v
                    }
                }
            }
            val stream = if (code >= 400) conn.errorStream else conn.inputStream
            return if (stream == null) "" else stream.use { String(it.readBytes(), Charsets.ISO_8859_1) }
        } finally {
            conn.disconnect()
        }
    }

    private fun enc(pw: String, hex: Boolean): String {
        val d = MessageDigest.getInstance("SHA-256").digest(pw.toByteArray(Charsets.UTF_8))
        val raw = if (hex) d.joinToString("") { "%02x".format(it) }.toByteArray(Charsets.UTF_8) else d
        return Base64.encodeToString(raw, Base64.NO_WRAP)
    }

    fun login(user: String, pw: String) {
        for (hex in listOf(true, false)) {
            cookies.clear()
            request("GET", "/")
            cookies["Language"] = "en"
            val r = request("POST", "/index/login.cgi", mapOf("Username" to user, "Password" to enc(pw, hex)))
            if (r.contains("txt_Username")) continue
            if (request("GET", wlanPage).contains("new stWlan")) return
            throw RouterException("The router rejected the session (another session is probably active). Wait 5 minutes and close any open router pages.")
        }
        throw RouterException("Router login failed (wrong username or password?). Wait a minute before trying again.")
    }

    fun logout() {
        request("GET", "/logout.cgi?RequestFile=html/logout.html")
    }

    private fun page(path: String): String {
        val t = request("GET", path)
        if (t.contains("var pageName") && t.length < 2000) {
            throw RouterException("Session closed (the router returned an empty page). Wait 2 minutes and try again.")
        }
        return t
    }

    private fun token(pageText: String): String {
        var t = Regex("csrf_token\\s*=\\s*\"?([^\";\\s]*)\"?").find(pageText)?.groupValues?.get(1) ?: "0"
        if (t == "0" || t.isEmpty()) {
            t = request("GET", "/html/ajaxref/updatacsrfajax.asp?r=" + System.currentTimeMillis())
                .trim().trim('"', '\'', ';', ' ')
        }
        return t
    }

    private fun post(pagePath: String, action: String, data: Map<String, String>) {
        val tok = token(page(pagePath))
        val dir = pagePath.substringBeforeLast("/") + "/"
        val body = LinkedHashMap<String, String>(data)
        body["csrf_token"] = tok
        val resp = request("POST", dir + action, body, base + pagePath)
        val err = Regex("var ErrInfo = (\\d+)").find(resp)
        if (err != null) throw RouterException("The router rejected the request (error code " + err.groupValues[1] + ").")
        log("  Sent")
    }

    fun setPpp(c: Config) {
        log("1) ADSL line settings...")
        post(
            pppPage,
            "setcfg.cgi?x1=${wan}&RequestFile=/html/quickconfig/quicksetwlan.asp",
            linkedMapOf(
                "x1.Username" to (c.pppDigits + c.pppSuffix),
                "x1.Password" to c.pppPass
            )
        )
    }

    fun setDsl(c: Config) {
        if (c.dsl == "none") return
        log("2) DSL settings...")
        val mode = c.dsl
        post(
            dslPage,
            "setcfg.cgi?RequestFile=" + dslPage,
            linkedMapOf(
                dslDomain + ".X_ConfigMode" to mode,
                dslDomain + ".X_Sra" to (if (c.sra) "1" else "0"),
                dslDomain + ".X_BitSwap" to (if (c.bitswap) "1" else "0")
            )
        )
    }

    private fun wlanRaw(t: String): Pair<List<String>, List<String>> {
        val m = Regex("var Wlan = new Array\\(new stWlan\\((.*?)\\)", RegexOption.DOT_MATCHES_ALL).find(t)
            ?: throw RouterException("Could not find the Wi-Fi settings in the page.")
        val a = quoted.findAll(m.groupValues[1]).map { it.groupValues[1] }.toList()
        val w = Regex("new stWps\\((.*?)\\)", RegexOption.DOT_MATCHES_ALL).find(t)
        val wps = if (w != null) quoted.findAll(w.groupValues[1]).map { it.groupValues[1] }.toList() else emptyList()
        return Pair(a, wps)
    }

    fun setWifi(c: Config) {
        log("3) Wi-Fi...")
        val (a, wps) = wlanRaw(page(wlanPage))
        if (a.size < 24) throw RouterException("The Wi-Fi page looks different than expected.")
        val wpsMode = if (wps.size > 2 && wps[2].isNotEmpty()) wps[2] else "ap-pin"
        val action = "setcfg.cgi?x=InternetGatewayDevice.LANDevice.1&y=${wlan}" +
            "&k=${wlan}.PreSharedKey.1&z=${wlan}.WPS&RequestFile=${wlanPage}"
        post(
            wlanPage,
            action,
            linkedMapOf(
                "y.Standard" to c.mode,
                "y.MaxBitRate" to "Auto",
                "y.X_Wlan11NHtMcs" to a[23],
                "y.Enable" to "1",
                "y.AutoChannelEnable" to "1",
                "y.Channel" to "6",
                "y.SSIDAdvertisementEnabled" to (if (c.hide) "0" else "1"),
                "y.X_WlanIsolateControl" to a[19],
                "y.WMMEnable" to "1",
                "y.X_Wlan11NBWControl" to a[20],
                "y.X_Wlan11NGIControl" to a[21],
                "y.SSID" to c.wifiSsid,
                "y.RegulatoryDomain" to a[17],
                "y.X_AssociateDeviceNum" to c.maxDevices.toString(),
                "y.X_PowerValue" to a[7],
                "y.BeaconType" to "11i",
                "z.Enable" to "0",
                "z.X_WPSMode" to wpsMode,
                "k.PreSharedKey" to c.wifiPass,
                "y.IEEE11iEncryptionModes" to "AESEncryption",
                "y.X_MixedAuthenticationMode" to "PSKAuthentication",
                "x.X_WLANEnable" to "1"
            )
        )
    }

    fun listDevices(): List<String> {
        val t = page("/html/status/ethenet.asp")
        val hostRe = Regex(
            "\\[\"InternetGatewayDevice\\.LANDevice\\.1\\.Hosts\\.Host\\.\\d+\"," +
                "\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"(\\d+)\",\"(\\d)\"\\]"
        )
        // groups: 1=type 2=ip 3=mac 4=lease seconds 5=active
        val hosts = hostRe.findAll(t).map { it.groupValues }.filter { it[5] == "1" }.toList()
        val upPorts = Regex("LANEthernetInterfaceConfig\\.\\d+\",\"(\\w+)\"")
            .findAll(t).count { it.groupValues[1] == "Up" }

        // Optional: Wi-Fi association list, used only to separate Wi-Fi from wired devices.
        val macRe = Regex("[0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5}")
        val wifiMacs = HashSet<String>()
        for (p in listOf("/html/status/wlaninfo.asp", "/html/status/wlan.asp")) {
            try {
                val w = request("GET", p)
                if (w.contains("AssociatedDevice")) {
                    macRe.findAll(w).forEach { wifiMacs.add(it.value.uppercase()) }
                }
            } catch (e: Exception) {
            }
        }

        fun lease(sec: String): String {
            val n = sec.toLongOrNull() ?: return sec
            if (n <= 0L) return "expired"
            val h = n / 3600
            val m = (n % 3600) / 60
            return if (h > 0) h.toString() + "h " + m + "m" else m.toString() + "m " + (n % 60) + "s"
        }

        fun fmt(i: Int, h: List<String>): String {
            return "  " + i + ". " + h[3].uppercase() + "  " + h[2] + "  (" + h[1] + ", lease " + lease(h[4]) + ")"
        }

        val out = ArrayList<String>()
        if (hosts.isEmpty()) {
            out.add("No active devices reported by the router.")
            return out
        }
        val wifi: List<List<String>>
        val other: List<List<String>>
        var title: String
        if (wifiMacs.isNotEmpty()) {
            wifi = hosts.filter { wifiMacs.contains(it[3].uppercase()) }
            other = hosts.filter { !wifiMacs.contains(it[3].uppercase()) }
            title = "Wi-Fi devices"
        } else if (upPorts == 0) {
            wifi = hosts
            other = emptyList()
            title = "Wi-Fi devices (all LAN ports are unplugged)"
        } else {
            wifi = hosts
            other = emptyList()
            title = "Connected devices (Wi-Fi + wired, " + upPorts + " LAN port(s) up)"
        }
        out.add(title + " - " + wifi.size + ":")
        for ((i, h) in wifi.withIndex()) out.add(fmt(i + 1, h))
        if (other.isNotEmpty()) {
            out.add("")
            out.add("Other devices (wired) - " + other.size + ":")
            for ((i, h) in other.withIndex()) out.add(fmt(i + 1, h))
        }
        return out
    }

    fun verify(): List<String> {
        val out = ArrayList<String>()
        out.add("")
        out.add("Current router settings:")
        val re = Regex("new WanPPPConstruction\\(\"([^\"]+)\",\"([^\"]*)\",\"(\\d)\",\"(\\d)\",\"([^\"]*)\"\\)")
        val ppp = re.findAll(page(pppPage)).firstOrNull { it.groupValues[1] == wan }
        if (ppp != null) {
            out.add("  Line: user=" + ppp.groupValues[2] + " | enabled=" + (ppp.groupValues[4] == "1"))
        } else {
            out.add("  Line: PPP data not found")
        }
        try {
            val d = Regex("new stDsl\\(\"[^\"]*\",\"([^\"]*)\",\"(\\d)\",\"(\\d)\"\\)").find(page(dslPage))
            if (d != null) {
                out.add("  DSL: mode=" + d.groupValues[1] + " | SRA=" + (d.groupValues[2] == "1") + " | Bitswap=" + (d.groupValues[3] == "1"))
            }
        } catch (e: Exception) {
        }
        val (a, _) = wlanRaw(page(wlanPage))
        out.add("  Wi-Fi: " + a[2] + " | hidden=" + (a[8] == "0") + " | devices=" + a[18] + " | security=" + a[9])
        return out
    }
}
