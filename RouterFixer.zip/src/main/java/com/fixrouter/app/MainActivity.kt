package com.fixrouter.app

import android.app.Activity
import android.content.Context
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Bundle
import android.text.InputType
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean

private val MODE_LABELS = arrayOf("802.11b", "802.11g", "802.11n", "802.11b/g", "802.11b/g/n")
private val MODE_VALUES = arrayOf("b", "g", "n", "b/g", "b/g/n")

class MainActivity : Activity() {
    private lateinit var scroll: ScrollView
    private lateinit var logView: TextView
    private lateinit var fixBtn: Button
    private lateinit var readBtn: Button
    private lateinit var etRouterUser: EditText
    private lateinit var etRouterPass: EditText
    private lateinit var etPppUser: EditText
    private lateinit var etPppPass: EditText
    private lateinit var etSsid: EditText
    private lateinit var etWifiPass: EditText
    private lateinit var etMax: EditText
    private lateinit var spMode: Spinner
    private lateinit var cbHide: CheckBox

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun gap(topDp: Int, bottomDp: Int): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, dp(topDp), 0, dp(bottomDp))
        return lp
    }

    private fun prefs() = getSharedPreferences("cfg", Context.MODE_PRIVATE)

    private fun field(
        hint: String,
        key: String,
        def: String,
        secret: Boolean = false,
        numeric: Boolean = false
    ): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(prefs().getString(key, def))
        e.inputType = if (numeric) {
            InputType.TYPE_CLASS_NUMBER
        } else if (secret) {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        } else {
            InputType.TYPE_CLASS_TEXT
        }
        return e
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(24), dp(20), dp(24))

        val title = TextView(this)
        title.text = "Router Fixer (HG531)"
        title.textSize = 22f
        root.addView(title)

        val note = TextView(this)
        note.text = "اتصل بواي فاي الراوتر (حتى لو مفتوحة وبدون إنترنت) ثم اضغط الزر. التطبيق بيكلم الراوتر بس."
        root.addView(note)

        etRouterUser = field("يوزر دخول الراوتر", "ru", "admin")
        etRouterPass = field("باسورد دخول الراوتر", "rp", "admin", secret = true)
        etPppUser = field("يوزر خط ADSL (أرقام بس)", "pu", "", numeric = true)
        etPppPass = field("باسورد خط ADSL", "pp", "", secret = true)
        etSsid = field("اسم الواي فاي", "ss", "")
        etWifiPass = field("باسورد الواي فاي (8 حروف على الأقل)", "wp", "", secret = true)
        etMax = field("أقصى عدد أجهزة", "mx", "5", numeric = true)
        root.addView(etRouterUser)
        root.addView(etRouterPass)
        root.addView(etPppUser)
        root.addView(etPppPass)
        root.addView(etSsid)
        root.addView(etWifiPass)
        root.addView(etMax)

        val modeLabel = TextView(this)
        modeLabel.text = "نوع الشبكة (Mode):"
        root.addView(modeLabel)
        spMode = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, MODE_LABELS)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spMode.adapter = adapter
        spMode.setSelection(prefs().getInt("mode", 4))
        root.addView(spMode)

        cbHide = CheckBox(this)
        cbHide.text = "إخفاء اسم الشبكة"
        cbHide.isChecked = prefs().getBoolean("hide", true)
        root.addView(cbHide)

        fixBtn = Button(this)
        fixBtn.text = "ظبّط الراوتر الآن"
        fixBtn.setOnClickListener { startJob(true) }
        root.addView(fixBtn, gap(36, 0))

        readBtn = Button(this)
        readBtn.text = "اقرأ الإعدادات الحالية"
        readBtn.setOnClickListener { startJob(false) }
        root.addView(readBtn, gap(24, 0))

        logView = TextView(this)
        logView.typeface = Typeface.MONOSPACE
        logView.textSize = 13f
        logView.setTextIsSelectable(true)
        root.addView(logView, gap(36, 0))

        scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun log(s: String) {
        runOnUiThread {
            logView.append(s + "\n")
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun setBusy(busy: Boolean) {
        runOnUiThread {
            fixBtn.isEnabled = !busy
            readBtn.isEnabled = !busy
        }
    }

    private fun bad(msg: String): Config? {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        return null
    }

    private fun readConfig(): Config? {
        val ppp = etPppUser.text.toString().trim()
        if (ppp.isEmpty() || ppp.length > 15 || !ppp.all { it in '0'..'9' }) {
            return bad("يوزر الخط لازم أرقام إنجليزي بس (حتى 15 رقم)")
        }
        val pppPass = etPppPass.text.toString()
        if (pppPass.isEmpty()) return bad("اكتب باسورد خط الـ ADSL")
        val ssid = etSsid.text.toString()
        if (ssid.isEmpty() || ssid.length > 32) return bad("اسم الواي فاي من 1 لـ 32 حرف")
        val wifiPass = etWifiPass.text.toString()
        if (wifiPass.length < 8 || wifiPass.length > 63) return bad("باسورد الواي فاي من 8 لـ 63 حرف")
        val max = etMax.text.toString().trim().toIntOrNull()
        if (max == null || max < 1 || max > 32) return bad("عدد الأجهزة من 1 لـ 32")
        return Config(
            routerUser = etRouterUser.text.toString().trim(),
            routerPass = etRouterPass.text.toString(),
            pppDigits = ppp,
            pppSuffix = "@tedata.net.eg",
            pppPass = pppPass,
            wifiSsid = ssid,
            wifiPass = wifiPass,
            hide = cbHide.isChecked,
            maxDevices = max,
            mode = MODE_VALUES[spMode.selectedItemPosition.coerceIn(0, MODE_VALUES.size - 1)]
        )
    }

    private fun save() {
        prefs().edit()
            .putString("ru", etRouterUser.text.toString())
            .putString("rp", etRouterPass.text.toString())
            .putString("pu", etPppUser.text.toString())
            .putString("pp", etPppPass.text.toString())
            .putString("ss", etSsid.text.toString())
            .putString("wp", etWifiPass.text.toString())
            .putString("mx", etMax.text.toString())
            .putBoolean("hide", cbHide.isChecked)
            .putInt("mode", spMode.selectedItemPosition)
            .apply()
    }

    private fun startJob(apply: Boolean) {
        val cfg = readConfig() ?: return
        save()
        logView.text = ""
        log("بدوّر على شبكة الواي فاي...")
        setBusy(true)

        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val req = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .build()
        val started = AtomicBoolean(false)
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                if (!started.compareAndSet(false, true)) return
                val self = this
                Thread {
                    work(network, cfg, apply)
                    try {
                        cm.unregisterNetworkCallback(self)
                    } catch (e: Exception) {
                    }
                }.start()
            }

            override fun onUnavailable() {
                log("مفيش واي فاي متصل. وصّل بشبكة الراوتر الأول وجرّب تاني.")
                setBusy(false)
            }
        }
        cm.requestNetwork(req, cb, 10000)
    }

    private fun work(network: Network, c: Config, apply: Boolean) {
        try {
            val r = Router(network) { msg -> log(msg) }
            log("بدخل الراوتر...")
            r.login(c.routerUser, c.routerPass)
            log("دخلت الراوتر.")
            if (apply) {
                r.setPpp(c)
                Thread.sleep(3000)
                r.setWifi(c)
                log("")
                log("خلص. استنى دقيقة والراوتر يطبّق الإعدادات.")
                log("الموبايل ممكن يتفصل لحظة ويرجع يتصل بالشبكة الجديدة.")
                try {
                    Thread.sleep(5000)
                    r.verify().forEach { line -> log(line) }
                } catch (e: Exception) {
                    log("مقدرتش أتحقق دلوقتي (طبيعي لو الواي فاي اتفصل). اضغط 'اقرأ الإعدادات الحالية' بعد دقيقة.")
                }
            } else {
                r.verify().forEach { line -> log(line) }
            }
        } catch (e: RouterException) {
            log("خطأ: " + e.message)
        } catch (e: Exception) {
            log("خطأ في الاتصال: " + (e.message ?: e.javaClass.simpleName))
        } finally {
            setBusy(false)
        }
    }
}

// ===================== Router client =====================

class RouterException(msg: String) : Exception(msg)

data class Config(
    val routerUser: String,
    val routerPass: String,
    val pppDigits: String,
    val pppSuffix: String,
    val pppPass: String,
    val wifiSsid: String,
    val wifiPass: String,
    val hide: Boolean,
    val maxDevices: Int,
    val mode: String
)

class Router(
    private val network: Network,
    private val base: String = "http://192.168.1.1",
    private val log: (String) -> Unit
) {
    private val cookies = LinkedHashMap<String, String>()
    private val wan = "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.1"
    private val wlan = "InternetGatewayDevice.LANDevice.1.WLANConfiguration.1"
    private val pppPage = "/html/quickconfig/quicksetppp.asp"
    private val wlanPage = "/html/ntwkall/wlan.asp"
    private val quoted = Regex("\"((?:[^\"\\\\]|\\\\.)*)\"")

    private fun request(
        method: String,
        path: String,
        form: Map<String, String>? = null,
        referer: String? = null
    ): String {
        val conn = network.openConnection(URL(base + path)) as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 10000
            conn.readTimeout = 20000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            if (cookies.isNotEmpty()) {
                conn.setRequestProperty("Cookie", cookies.entries.joinToString("; ") { it.key + "=" + it.value })
            }
            if (referer != null) conn.setRequestProperty("Referer", referer)
            if (form != null) {
                val body = form.entries.joinToString("&") {
                    URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
                }.toByteArray(Charsets.UTF_8)
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                conn.setFixedLengthStreamingMode(body.size)
                conn.outputStream.use { it.write(body) }
            }
            val code = conn.responseCode
            for ((hk, hv) in conn.headerFields) {
                if (hk != null && hk.equals("Set-Cookie", ignoreCase = true)) {
                    for (c in hv) {
                        val kv = c.substringBefore(";")
                        val k = kv.substringBefore("=").trim()
                        val v = kv.substringAfter("=", "").trim()
                        if (k.isNotEmpty()) cookies[k] = v
                    }
                }
            }
            val stream = if (code >= 400) conn.errorStream else conn.inputStream
            return if (stream == null) "" else stream.use { String(it.readBytes(), Charsets.ISO_8859_1) }
        } finally {
            conn.disconnect()
        }
    }

    private fun enc(pw: String, hex: Boolean): String {
        val d = MessageDigest.getInstance("SHA-256").digest(pw.toByteArray(Charsets.UTF_8))
        val raw = if (hex) d.joinToString("") { "%02x".format(it) }.toByteArray(Charsets.UTF_8) else d
        return Base64.encodeToString(raw, Base64.NO_WRAP)
    }

    fun login(user: String, pw: String) {
        for (hex in listOf(true, false)) {
            cookies.clear()
            request("GET", "/")
            cookies["Language"] = "en"
            val r = request("POST", "/index/login.cgi", mapOf("Username" to user, "Password" to enc(pw, hex)))
            if (r.contains("txt_Username")) continue
            if (request("GET", wlanPage).contains("new stWlan")) return
            throw RouterException("الراوتر مش قابل الجلسة (غالباً في جلسة تانية شغالة). استنى 5 دقايق واقفل أي صفحة راوتر مفتوحة.")
        }
        throw RouterException("فشل الدخول للراوتر (اليوزر أو الباسورد غلط؟). استنى دقيقة قبل ما تحاول تاني.")
    }

    private fun page(path: String): String {
        val t = request("GET", path)
        if (t.contains("var pageName") && t.length < 2000) {
            throw RouterException("الجلسة اتقفلت (الراوتر رجّع صفحة فاضية). استنى دقيقتين وجرّب تاني.")
        }
        return t
    }

    private fun token(pageText: String): String {
        var t = Regex("csrf_token\\s*=\\s*\"?([^\";\\s]*)\"?").find(pageText)?.groupValues?.get(1) ?: "0"
        if (t == "0" || t.isEmpty()) {
            t = request("GET", "/html/ajaxref/updatacsrfajax.asp?r=" + System.currentTimeMillis())
                .trim().trim('"', '\'', ';', ' ')
        }
        return t
    }

    private fun post(pagePath: String, action: String, data: Map<String, String>) {
        val tok = token(page(pagePath))
        val dir = pagePath.substringBeforeLast("/") + "/"
        val body = LinkedHashMap<String, String>(data)
        body["csrf_token"] = tok
        val resp = request("POST", dir + action, body, base + pagePath)
        val err = Regex("var ErrInfo = (\\d+)").find(resp)
        if (err != null) throw RouterException("الراوتر رفض الطلب (كود الخطأ " + err.groupValues[1] + ").")
        log("  تم الإرسال")
    }

    fun setPpp(c: Config) {
        log("1) بيانات خط الـ ADSL...")
        post(
            pppPage,
            "setcfg.cgi?x1=${wan}&RequestFile=/html/quickconfig/quicksetwlan.asp",
            linkedMapOf(
                "x1.Username" to (c.pppDigits + c.pppSuffix),
                "x1.Password" to c.pppPass
            )
        )
    }

    private fun wlanRaw(t: String): Pair<List<String>, List<String>> {
        val m = Regex("var Wlan = new Array\\(new stWlan\\((.*?)\\)", RegexOption.DOT_MATCHES_ALL).find(t)
            ?: throw RouterException("مش لاقي إعدادات الواي فاي في الصفحة.")
        val a = quoted.findAll(m.groupValues[1]).map { it.groupValues[1] }.toList()
        val w = Regex("new stWps\\((.*?)\\)", RegexOption.DOT_MATCHES_ALL).find(t)
        val wps = if (w != null) quoted.findAll(w.groupValues[1]).map { it.groupValues[1] }.toList() else emptyList()
        return Pair(a, wps)
    }

    fun setWifi(c: Config) {
        log("2) الواي فاي...")
        val (a, wps) = wlanRaw(page(wlanPage))
        if (a.size < 24) throw RouterException("صفحة الواي فاي شكلها مختلف عن المتوقع.")
        val wpsMode = if (wps.size > 2 && wps[2].isNotEmpty()) wps[2] else "ap-pin"
        val action = "setcfg.cgi?x=InternetGatewayDevice.LANDevice.1&y=${wlan}" +
            "&k=${wlan}.PreSharedKey.1&z=${wlan}.WPS&RequestFile=${wlanPage}"
        post(
            wlanPage,
            action,
            linkedMapOf(
                "y.Standard" to c.mode,
                "y.MaxBitRate" to "Auto",
                "y.X_Wlan11NHtMcs" to a[23],
                "y.Enable" to "1",
                "y.AutoChannelEnable" to "1",
                "y.Channel" to "6",
                "y.SSIDAdvertisementEnabled" to (if (c.hide) "0" else "1"),
                "y.X_WlanIsolateControl" to a[19],
                "y.WMMEnable" to "1",
                "y.X_Wlan11NBWControl" to a[20],
                "y.X_Wlan11NGIControl" to a[21],
                "y.SSID" to c.wifiSsid,
                "y.RegulatoryDomain" to a[17],
                "y.X_AssociateDeviceNum" to c.maxDevices.toString(),
                "y.X_PowerValue" to a[7],
                "y.BeaconType" to "11i",
                "z.Enable" to "0",
                "z.X_WPSMode" to wpsMode,
                "k.PreSharedKey" to c.wifiPass,
                "y.IEEE11iEncryptionModes" to "AESEncryption",
                "y.X_MixedAuthenticationMode" to "PSKAuthentication",
                "x.X_WLANEnable" to "1"
            )
        )
    }

    fun verify(): List<String> {
        val out = ArrayList<String>()
        out.add("")
        out.add("الإعدادات الحالية في الراوتر:")
        val re = Regex("new WanPPPConstruction\\(\"([^\"]+)\",\"([^\"]*)\",\"(\\d)\",\"(\\d)\",\"([^\"]*)\"\\)")
        val ppp = re.findAll(page(pppPage)).firstOrNull { it.groupValues[1] == wan }
        if (ppp != null) {
            out.add("  الخط: يوزر=" + ppp.groupValues[2] + " | مفعّل=" + (ppp.groupValues[4] == "1"))
        } else {
            out.add("  الخط: مش لاقي بيانات PPP")
        }
        val (a, _) = wlanRaw(page(wlanPage))
        out.add("  الواي فاي: " + a[2] + " | مخفي=" + (a[8] == "0") + " | أجهزة=" + a[18] + " | أمان=" + a[9])
        return out
    }
}
